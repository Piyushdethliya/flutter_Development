import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart';

class VoiceInputScreen extends StatefulWidget {
  @override
  _VoiceInputScreenState createState() => _VoiceInputScreenState();
}

class _VoiceInputScreenState extends State<VoiceInputScreen> {
  SpeechToText speech = SpeechToText();
  bool isListening = false;
  String recognizedText = "Press the button and start speaking...";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Voice Input"),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    padding: EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      color: Colors.teal.shade50,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      recognizedText,
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w500,
                        color: Colors.black87,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 30),
              GestureDetector(
                onTap: () async {
                  if (!isListening) {
                    bool available = await speech.initialize();
                    if (available) {
                      setState(() => isListening = true);
                      speech.listen(onResult: (result) {
                        setState(() => recognizedText = result.recognizedWords);
                      });
                    }
                  } else {
                    speech.stop();
                    setState(() => isListening = false);
                  }
                },
                child: CircleAvatar(
                  radius: 50,
                  backgroundColor: isListening ? Colors.red : Colors.teal,
                  child: Icon(
                    isListening ? Icons.mic_off : Icons.mic,
                    color: Colors.white,
                    size: 40,
                  ),
                ),
              ),
              SizedBox(height: 20),
              Text(
                isListening ? "Listening..." : "Tap the mic to start",
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
