import 'package:flutter/material.dart';

class NotificationBadge extends StatelessWidget {
  final int count;

  NotificationBadge(this.count);

  @override
  Widget build(BuildContext context) {
    return Visibility(
      visible: count > 0,
      child: Container(
        padding: count > 9
            ? EdgeInsets.symmetric(horizontal: 8, vertical: 4)
            : EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: Colors.redAccent,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 4,
              offset: Offset(0, 2),
            ),
          ],
        ),
        constraints: BoxConstraints(
          minWidth: 20,
          minHeight: 20,
        ),
        child: Text(
          count > 99 ? '99+' : count.toString(),
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: count > 9 ? 10 : 12,
          ),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
