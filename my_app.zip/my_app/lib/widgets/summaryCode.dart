import 'package:flutter/material.dart';

class SummaryScreen extends StatefulWidget {
  @override
  _SummaryScreenState createState() => _SummaryScreenState();
}

class _SummaryScreenState extends State<SummaryScreen> {
  int notificationCount = 0;

  void simulateNotification() {
    setState(() {
      notificationCount++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Summary Page'),
        centerTitle: true,
        backgroundColor: Colors.teal,
        actions: [
          // Notification Icon with Badge
          Stack(
            children: [
              IconButton(
                icon: Icon(Icons.notifications, size: 28),
                onPressed: () {
                  // Display notification details
                  showDialog(
                    context: context,
                    builder: (context) {
                      return AlertDialog(
                        title: Text('Notifications'),
                        content: Text(
                          notificationCount > 0
                              ? 'You have $notificationCount new notifications.'
                              : 'No new notifications.',
                        ),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: Text('Close'),
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
              // Badge for notification count
              if (notificationCount > 0)
                Positioned(
                  right: 8,
                  top: 8,
                  child: Container(
                    padding: EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      shape: BoxShape.circle,
                    ),
                    child: Text(
                      notificationCount > 99 ? '99+' : '$notificationCount',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "App Features Overview",
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: Colors.teal.shade700,
                  ),
                ),
                Divider(thickness: 2, height: 30, color: Colors.teal.shade300),

                // Features and details
                _buildFeatureSection(
                  context,
                  title: "1. Voice Input",
                  description:
                      "Voice Input allows users to input text using speech recognition. The app listens to voice commands, converts them into text, and displays the recognized text for use in other app features.",
                ),
                _buildFeatureSection(
                  context,
                  title: "2. Auto Reply",
                  description:
                      "The Auto Reply feature provides automatic responses to the messages entered by the user. It simulates a basic messaging conversation with a two-second delay in response.",
                ),
                _buildFeatureSection(
                  context,
                  title: "3. Notifications",
                  description:
                      "The Notifications feature displays an icon on the app bar that shows the count of new notifications. Users can click on the icon to see more details about their notifications.",
                ),

                SizedBox(height: 20),

                // Button to simulate notifications
                Center(
                  child: ElevatedButton(
                    onPressed: simulateNotification,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal,
                      padding:
                          EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: Text(
                      'Simulate New Notification',
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                ),

                SizedBox(height: 30),

                Center(
                  child: Text(
                    "Enjoy using the app!",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.teal.shade800,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFeatureSection(BuildContext context,
      {required String title, required String description}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.teal.shade600,
          ),
        ),
        SizedBox(height: 10),
        Text(
          description,
          style: TextStyle(fontSize: 16, height: 1.5),
        ),
        SizedBox(height: 20),
      ],
    );
  }
}
