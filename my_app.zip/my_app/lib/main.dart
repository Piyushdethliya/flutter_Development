import 'package:flutter/material.dart';
import 'package:my_app/auto_reply_screen.dart';
import 'package:my_app/dashboard_screen.dart';
import 'package:my_app/notification_page.dart';
import 'package:my_app/voice_input_screen.dart';
import 'package:my_app/widgets/summaryCode.dart';
// import 'screens/dashboard_screen.dart';
// import 'screens/voice_input_screen.dart';
// import 'screens/auto_reply_screen.dart';
// import 'screens/summary_screen.dart';
// import 'screens/notification_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      // Setting up the home screen and routes for navigation
      initialRoute: '/',
      routes: {
        '/': (context) => DashboardScreen(),
        '/voiceInput': (context) => VoiceInputScreen(),
        '/autoReply': (context) => AutoReplyScreen(),
        '/summary': (context) => SummaryScreen(),
        '/notifications': (context) => NotificationPage(),
      },
    );
  }
}
