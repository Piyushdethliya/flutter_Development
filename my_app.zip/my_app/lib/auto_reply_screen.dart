import 'package:flutter/material.dart';
import 'dart:async';

class AutoReplyScreen extends StatefulWidget {
  @override
  _AutoReplyScreenState createState() => _AutoReplyScreenState();
}

class _AutoReplyScreenState extends State<AutoReplyScreen> {
  TextEditingController _controller = TextEditingController();
  List<String> messages = [];

  void sendAutoReply(String message) {
    // Add user's message to the chat
    setState(() {
      messages.add("You: $message");
    });

    // Predefined responses based on user message
    String autoReplyMessage = "";
    if (message.toLowerCase() == "hi") {
      autoReplyMessage = "Auto Reply: Hello!";
    } else if (message.toLowerCase() == "how are you?") {
      autoReplyMessage = "Auto Reply: I'm fine, thank you for asking!";
    } else {
      autoReplyMessage =
          "Auto Reply: This is an automatic response to your message: '$message'";
    }

    // Simulate a delay for the auto reply
    Future.delayed(Duration(seconds: 2), () {
      setState(() {
        messages.add(autoReplyMessage);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Auto Reply Chat'),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: messages.length,
                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                itemBuilder: (context, index) {
                  bool isUserMessage = messages[index].startsWith("You:");
                  return Align(
                    alignment: isUserMessage
                        ? Alignment.centerRight
                        : Alignment.centerLeft,
                    child: Card(
                      color:
                          isUserMessage ? Colors.teal[100] : Colors.grey[200],
                      margin: EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Text(
                          messages[index],
                          style: TextStyle(fontSize: 16),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      decoration: InputDecoration(
                        labelText: 'Type your message',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        filled: true,
                        fillColor: Colors.grey[200],
                      ),
                    ),
                  ),
                  SizedBox(width: 8),
                  FloatingActionButton(
                    onPressed: () {
                      String userMessage = _controller.text;
                      if (userMessage.isNotEmpty) {
                        sendAutoReply(userMessage);
                        _controller.clear();
                      }
                    },
                    backgroundColor: Colors.teal,
                    child: Icon(Icons.send, color: Colors.white),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
